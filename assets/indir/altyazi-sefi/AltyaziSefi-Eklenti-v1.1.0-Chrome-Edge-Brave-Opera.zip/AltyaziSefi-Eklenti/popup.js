/* Altyazı Şefi eklentisi: simgeye basınca açılan pencere.
 * Önce kilit (sitedeki kilit ekranı, cihaz kodu ve karekoduyla); açıksa: bu sekmede başlat/durdur, durum,
 * altyazı yerini ayarla, YouTube düğmesi ve ayarlar. Komutlar arka plana gider (bg.js); pencere kapanınca
 * çeviri sürer. Chrome/Edge'de sekmeyi yakalama izni (tabCapture) burada, kullanıcının tıklamasıyla alınır. */
(function () {
  'use strict';
  var C = (typeof chrome !== 'undefined' && chrome.runtime) ? chrome : browser;
  var AS = window.AS;
  var U = AS.util;
  var el = U.el;
  var rootEl = document.getElementById('as-root');

  var tab = null;
  var state = null;
  var ui = {};
  var pollTimer = null;
  var busy = false;

  /* ---------------- kilit ekranının sözleri eklentiye göre ---------------- */
  var WORDS = [
    ['Bu site izinle kullanılır. Bu bilgisayarda bir kez etkinleştirmeniz yeterli.', 'Bu eklenti izinle kullanılır. Bu tarayıcıda bir kez etkinleştirmeniz yeterli.'],
    ['Kod yalnızca bu bilgisayarda ve bu tarayıcıda çalışır. Tarayıcı verilerini silerseniz yeni bir kod gerekir. Etkinleştirdikten sonra internet olmadan da açılır.',
      'Kod yalnızca bu tarayıcıdaki bu eklentide çalışır. Eklentiyi kaldırıp yeniden kurarsanız yeni bir kod gerekir.'],
    ['Bu bilgisayarın kodu', 'Bu eklentinin kodu']
  ];
  function fixWords(node) {
    var w = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
    var t;
    while ((t = w.nextNode())) {
      for (var i = 0; i < WORDS.length; i++) if (t.nodeValue === WORDS[i][0]) t.nodeValue = WORDS[i][1];
    }
  }
  var wordObs = new MutationObserver(function () { fixWords(rootEl); });
  wordObs.observe(rootEl, { childList: true, subtree: true });

  /* ---------------- arka plan ---------------- */
  function bg(cmd, extra) {
    var m = { to: 'bg', cmd: cmd, tabId: tab ? tab.id : null };
    if (extra) for (var k in extra) m[k] = extra[k];
    try {
      var p = C.runtime.sendMessage(m);
      return Promise.resolve(p).then(function (r) { return r || { ok: false }; }, function (e) { return { ok: false, error: e && e.message }; });
    } catch (e) { return Promise.resolve({ ok: false, error: e && e.message }); }
  }

  function hostOf(url) { try { var u = new URL(url); return u.hostname; } catch (e) { return ''; } }
  function pageKind(url) {
    if (!url) return 'none';
    if (!/^https?:/i.test(url) && !/^file:/i.test(url)) return 'internal';
    if (/^https:\/\/(chrome\.google\.com\/webstore|chromewebstore\.google\.com|microsoftedge\.microsoft\.com\/addons)/i.test(url)) return 'internal';
    if (/^https:\/\/([a-z0-9-]+\.)?youtube\.com\//i.test(url)) return 'youtube';
    return 'web';
  }

  /** Chrome/Edge: bu sekmenin görüntü+ses akışı için kimlik (tıklama anında alınmalı) */
  function streamId(tabId) {
    return new Promise(function (resolve, reject) {
      try {
        C.tabCapture.getMediaStreamId({ targetTabId: tabId }, function (id) {
          var err = C.runtime.lastError;
          if (err || !id) reject(new Error(capErr(err && err.message)));
          else resolve(id);
        });
      } catch (e) { reject(new Error(capErr(e && e.message))); }
    });
  }
  function capErr(m) {
    m = String(m || '');
    if (/active stream/i.test(m)) return 'Bu sekme zaten yakalanıyor (başka bir eklenti ya da paylaşım olabilir). Onu kapatıp yeniden deneyin.';
    if (/invoked|activeTab|permission/i.test(m)) return 'Tarayıcı izin vermedi. Film sekmesindeyken eklenti simgesine basıp yeniden deneyin.';
    if (/chrome:\/\/|Chrome pages|cannot be captured/i.test(m)) return 'Bu sayfa yakalanamaz. Videonun açık olduğu sekmede deneyin.';
    return 'Sekme yakalanamadı' + (m ? ': ' + m : '.');
  }

  /* ---------------- arayüz ---------------- */
  function opt(value, label, sel) { return el('option', { value: value, selected: sel ? true : null }, label); }

  function build() {
    U.clear(rootEl);
    var kind = pageKind(tab && tab.url);
    var host = tab ? hostOf(tab.url) : '';
    var caps = state.caps || {};
    var en = state.engine || {};
    var sty = state.style || {};

    ui.start = el('button', { class: 'btn btn--go', type: 'button', 'data-role': 'start' }, 'Bu sekmede çevir');
    ui.status = el('p', { class: 'pp-status', role: 'status', 'aria-live': 'polite', 'data-role': 'status' });
    ui.bar = el('div', { class: 'pp-prog', hidden: true }, el('span'));
    ui.other = el('p', { class: 'pp-note', hidden: true });
    ui.edit = el('button', { class: 'btn', type: 'button', 'data-role': 'edit' }, 'Altyazı yerini ayarla');

    var top = el('header', { class: 'pp-head' },
      el('img', { src: 'icons/icon-48.png', alt: '', width: '32', height: '32' }),
      el('div', null, el('div', { class: 'pp-name' }, 'Altyazı Şefi'),
        el('div', { class: 'pp-sub' }, kind === 'web' || kind === 'youtube' ? host : 'Türkçe altyazı')));

    var main = el('section', { class: 'pp-main' });
    if (kind === 'internal' || kind === 'none') {
      main.appendChild(el('p', { class: 'pp-note' }, 'Bu sayfada çalışmaz. Videonun açık olduğu sekmeye geçip simgeye yeniden basın.'));
    } else {
      main.appendChild(ui.start);
      main.appendChild(ui.status);
      main.appendChild(ui.bar);
      main.appendChild(ui.other);
    }
    if (kind === 'youtube') {
      ui.yt = el('button', { class: 'btn', type: 'button', 'data-role': 'yt' }, 'YouTube altyazısını çevir');
      main.appendChild(el('div', { class: 'pp-yt' },
        ui.yt,
        el('p', { class: 'pp-hint' }, 'Videonun kendi altyazısını alıp çevirir, reklamları atlar. Altyazısı olmayan videolarda yukarıdaki “Bu sekmede çevir”i kullanın.')));
    }

    // ayarlar
    ui.mode = el('select', { id: 'pp-mode', 'data-role': 'mode' },
      opt('auto', 'Otomatik (önce ekrandaki yazı)', en.liveMode === 'auto'),
      opt('ocr', 'Yalnızca ekrandaki altyazı', en.liveMode === 'ocr'),
      opt('speech', 'Yalnızca konuşma', en.liveMode === 'speech'));
    if (!caps.speech) ui.mode.querySelector('option[value="speech"]').disabled = true;
    ui.lang = el('select', { id: 'pp-lang', 'data-role': 'lang' });
    U.LANGS.forEach(function (l) { ui.lang.appendChild(opt(l[0], l[1], en.asrLang === l[0])); });
    ui.model = el('select', { id: 'pp-model', 'data-role': 'model' },
      opt('tiny', 'Hızlı (yaklaşık 40 MB)', en.asrModel === 'tiny'),
      opt('base', 'Dengeli (yaklaşık 80–130 MB)', en.asrModel === 'base'),
      opt('small', 'En doğru (yaklaşık 250–450 MB)', en.asrModel === 'small'));
    ui.size = el('input', { id: 'pp-size', type: 'range', min: '1.8', max: '9', step: '0.2', value: String(sty.size), 'data-role': 'size' });
    ui.bg = el('input', { id: 'pp-bg', type: 'range', min: '0', max: '0.9', step: '0.05', value: String(sty.bg), 'data-role': 'bg' });
    ui.orig = el('input', { id: 'pp-orig', type: 'checkbox', checked: sty.showOriginal ? true : null, 'data-role': 'orig' });

    var set = el('details', { class: 'pp-set', 'data-role': 'settings' },
      el('summary', null, 'Ayarlar'),
      el('p', { class: 'pp-hint' }, 'Türkçe yazı yanlış yerdeyse ya da altyazı okunmuyorsa önce çeviriyi başlatın, sonra:'),
      el('div', { class: 'pp-row' }, ui.edit),
      el('label', { for: 'pp-mode' }, 'Neyi çevirsin?'), ui.mode,
      caps.speech ? null : el('p', { class: 'pp-hint' }, 'Bu tarayıcı eklentilere sekmenin sesini vermiyor: konuşma çevirisi yalnızca Chrome, Edge, Brave ve Opera\'da var.'),
      el('label', { for: 'pp-lang' }, 'Videonun dili'), ui.lang,
      el('label', { for: 'pp-size' }, 'Yazı boyu'), ui.size,
      el('label', { for: 'pp-bg' }, 'Yazının arka planı (en solda şeffaf)'), ui.bg,
      el('label', { class: 'pp-check' }, ui.orig, ' Yabancı yazıyı da altında göster'),
      caps.speech ? el('details', { class: 'pp-adv' }, el('summary', null, 'Konuşma tanıma modeli'),
        el('label', { for: 'pp-model' }, 'İlk kullanımda bir kez indirilir'), ui.model) : null);

    var dev = '';
    try { dev = AS.lock.device(); } catch (e) { dev = ''; }
    var exp = AS.lock.expires && AS.lock.expires();
    var foot = el('footer', { class: 'pp-foot' },
      'Eklentinin kodu: ' + dev + (exp ? ' · kod ' + exp.toLocaleDateString('tr-TR') + ' tarihine kadar geçerli' : ''));

    rootEl.appendChild(el('div', { class: 'pp' }, top, main, set, foot));

    ui.start.addEventListener('click', onStart);
    ui.edit.addEventListener('click', function () {
      bg('edit', { on: true }).then(function (r) {
        if (r && r.ok) window.close();
        else showStatus((r && r.error) || 'Önce bu sekmede çeviriyi başlatın.', 'warn');
      });
    });
    if (ui.yt) ui.yt.addEventListener('click', function () {
      ui.yt.disabled = true;
      bg('yt').then(function (r) {
        ui.yt.disabled = false;
        if (r && r.ok) window.close();
        else showStatus((r && r.error) || 'YouTube kısmı açılamadı.', 'error');
      });
    });
    var saveEngine = function () { bg('engine', { engine: { liveMode: ui.mode.value, asrLang: ui.lang.value, asrModel: ui.model.value } }); };
    ui.mode.addEventListener('change', saveEngine);
    ui.lang.addEventListener('change', saveEngine);
    ui.model.addEventListener('change', saveEngine);
    var styleT = null;
    var saveStyle = function () {
      clearTimeout(styleT);
      styleT = setTimeout(function () {
        bg('style', { style: { size: Number(ui.size.value), bg: Number(ui.bg.value), showOriginal: ui.orig.checked } });
      }, 120);
    };
    ui.size.addEventListener('input', saveStyle);
    ui.bg.addEventListener('input', saveStyle);
    ui.orig.addEventListener('change', saveStyle);
    update();
  }

  function showStatus(text, level) {
    if (!ui.status) return;
    ui.status.textContent = text || '';
    ui.status.className = 'pp-status' + (level ? ' is-' + level : '');
  }

  function update() {
    var s = state && state.session;
    var here = !!(s && s.here);
    if (ui.start && !busy) {
      ui.start.textContent = here ? 'Durdur' : 'Bu sekmede çevir';
      ui.start.className = 'btn ' + (here ? 'btn--stop' : 'btn--go');
      ui.start.disabled = false;
    }
    if (ui.edit) ui.edit.disabled = !here;
    if (ui.other) {
      ui.other.hidden = !(s && !s.here);
      if (s && !s.here) ui.other.textContent = 'Şu an başka bir sekmede çeviri açık' + (s.host ? ' (' + s.host + ')' : '') + '. Burada başlatırsanız o durur.';
    }
    if (!busy) {
      if (here) showStatus(s.status || 'Çeviri açık.', s.level === 'busy' ? 'busy' : s.level);
      else if (!ui.status || !ui.status.dataset.keep) showStatus(state && state.caps && state.caps.engine === 'tab'
        ? 'Filmi açın, sonra “Bu sekmede çevir”e basın. Bu tarayıcıda yalnızca ekrandaki altyazı okunur.'
        : 'Filmi açın, sonra “Bu sekmede çevir”e basın.', '');
    }
    if (ui.bar) {
      var p = here && s.progress;
      ui.bar.hidden = !p;
      if (p) {
        var f = p.total > 0 ? Math.min(1, p.loaded / p.total) : 0;
        ui.bar.firstChild.style.width = (f * 100).toFixed(1) + '%';
        ui.bar.title = p.label || '';
      }
    }
  }

  function onStart() {
    if (busy) return;
    var here = !!(state && state.session && state.session.here);
    busy = true;
    ui.start.disabled = true;
    if (here) {
      showStatus('Durduruluyor…', 'busy');
      bg('stop').then(done);
      return;
    }
    showStatus('Başlatılıyor…', 'busy');
    var p = (state.caps && state.caps.tabCapture)
      ? streamId(tab.id).then(function (id) { return bg('start', { streamId: id }); })
      : bg('start', { windowId: tab.windowId });
    p.then(function (r) {
      if (!r || !r.ok) {
        ui.status.dataset.keep = '1';
        showStatus((r && r.error) || 'Başlatılamadı.', 'error');
      } else delete ui.status.dataset.keep;
      done();
    }, function (e) {
      ui.status.dataset.keep = '1';
      showStatus((e && e.message) || String(e), 'error');
      done();
    });
    function done() { busy = false; refresh(); }
  }

  function refresh() {
    return bg('state').then(function (s) {
      if (s && s.caps) { state = s; update(); }
    });
  }

  function main() {
    wordObs.disconnect();
    // ?tab=<kimlik>: pencere sekme olarak açıldığında (testler) hedef sekme
    var want = Number(new URLSearchParams(location.search).get('tab'));
    var q = want > 0 ? C.tabs.get(want).then(function (t) { return [t]; }) : C.tabs.query({ active: true, currentWindow: true });
    q.then(function (tabs) {
      tab = (tabs && tabs[0]) || null;
      return bg('state');
    }).then(function (s) {
      state = (s && s.caps) ? s : { caps: {}, style: {}, engine: {}, session: null };
      build();
      pollTimer = setInterval(refresh, 700);
    });
  }

  /* ---------------- ilk kurulum sırası ---------------- */
  function stepsBar(n) {
    var names = ['Kodu al', 'Kodu yapıştır', 'Simgeyi sabitle'];
    var ol = el('ol', { class: 'pp-steps', 'data-role': 'steps' });
    names.forEach(function (t, i) {
      ol.appendChild(el('li', { class: i + 1 < n ? 'is-done' : (i + 1 === n ? 'is-now' : '') }, el('b', null, String(i + 1)), ' ' + t));
    });
    return ol;
  }
  function lockHelp() {
    return el('div', { class: 'pp-lockhelp', 'data-role': 'lock-help' }, stepsBar(1),
      el('p', null, el('b', null, '1. '), 'Aşağıdaki karekodu Serkan\'a göster ya da bu ekranın fotoğrafını gönder.'),
      el('p', null, el('b', null, '2. '), 'Serkan onaylayınca bu pencere birkaç saniye içinde kendiliğinden açılır. Pencere kapanırsa simgeye yeniden bas.'),
      el('p', null, el('b', null, 'Ya da: '), 'Kod mesajla gelirse aşağıdaki kutuya yapıştır ve "Etkinleştir"e bas.'));
  }
  function pinned() {
    try {
      if (C.action && C.action.getUserSettings) return C.action.getUserSettings().then(function (u) { return !!(u && u.isOnToolbar); }, function () { return null; });
    } catch (e) { /* yok */ }
    return Promise.resolve(null);
  }
  /** Kilit açıldıktan sonra bir kez: simgeyi araç çubuğuna sabitleme ve nasıl kullanılır */
  function onboarding(next) {
    C.storage.local.get('onboarded').then(function (r) {
      if (r && r.onboarded) return next();
      U.clear(rootEl);
      var isChrome = !!(C.action && C.action.getUserSettings);
      var pinMsg = el('p', { class: 'pp-status', 'data-role': 'pin-status' });
      var go = el('button', { class: 'btn btn--go', type: 'button', 'data-role': 'onboard-done' }, 'Tamam, başla');
      rootEl.appendChild(el('div', { class: 'pp' },
        el('header', { class: 'pp-head' }, el('img', { src: 'icons/icon-48.png', alt: '', width: '32', height: '32' }),
          el('div', null, el('div', { class: 'pp-name' }, 'Etkinleştirildi'), el('div', { class: 'pp-sub' }, 'Son adım'))),
        stepsBar(3),
        el('p', { class: 'pp-note' }, isChrome
          ? 'Sağ üstteki yap-boz simgesine bas, Altyazı Şefi\'nin yanındaki raptiyeye dokun. Simge araç çubuğunda kalır.'
          : 'Altyazı Şefi simgesi adres çubuğunun yanında durur. Görmüyorsan araç çubuğuna sağ tıklayıp "Özelleştir" ile ekle.'),
        pinMsg,
        el('p', { class: 'pp-hint' }, 'Kullanmak için: filmi aç ve oynat, simgeye bas, "Bu sekmede çevir" de.'),
        go));
      var check = function () {
        pinned().then(function (on) {
          if (on === true) { pinMsg.textContent = 'Simge araç çubuğunda.'; pinMsg.className = 'pp-status is-ok'; }
          else if (on === false) { pinMsg.textContent = 'Simge henüz sabitlenmedi.'; pinMsg.className = 'pp-status is-warn'; }
        });
      };
      check();
      var t = setInterval(check, 1000);
      go.addEventListener('click', function () {
        clearInterval(t);
        C.storage.local.set({ onboarded: true }).then(next, next);
      });
    }, next);
  }

  document.body.classList.add('is-locked');
  var help = lockHelp();
  rootEl.parentNode.insertBefore(help, rootEl);
  AS.lock.gate(function () {
    document.body.classList.remove('is-locked');
    if (help.parentNode) help.parentNode.removeChild(help);
    onboarding(main);
  });
  window.addEventListener('unload', function () { if (pollTimer) clearInterval(pollTimer); });
})();
