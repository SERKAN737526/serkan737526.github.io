/* Altyazı Şefi eklentisi: arka plan (Chrome/Edge'de service worker, Firefox/Safari'de arka plan betiği).
 *
 * Görevi yalnızca yönlendirmek:
 *   açılır pencere (popup) → "başlat/durdur/ayarla" komutları → çeviri motoru (engine.html)
 *   motor → Türkçe satırlar, durum → sekmedeki katman (overlay.js, her çerçevede)
 *   katman → ekran boyu, tam ekran, kaydedilen yerleşim → motorun okuma bölgesi
 * Motor Chrome/Edge'de görünmeyen bir "offscreen" belgede (sekmenin görüntüsü ve sesi chrome.tabCapture ile),
 * Firefox/Safari'de küçük bir eklenti penceresinde (yalnızca görüntü, tabs.captureVisibleTab ile) çalışır.
 *
 * Güvenlik: komutları yalnızca eklentinin kendi sayfaları (popup, motor) verebilir. Sayfalardaki katmandan gelen
 * iletiler yalnızca kendi sekmesiyle ilgili ölçü ve yerleşim bildirebilir; sayılar denetlenir, metin kabul edilmez.
 * Aynı anda tek sekme çevrilir. Oturum bilgisi chrome.storage.session'da tutulur (service worker uyuyup uyanabilir). */
'use strict';

var C = (typeof chrome !== 'undefined' && chrome.runtime) ? chrome : browser;
if (typeof importScripts === 'function' && !(self.AS && self.AS.ytBookmarklet)) {
  try { importScripts('js/yt-bookmarklet.js'); } catch (e) { /* YouTube düğmesi çalışmaz; geri kalanı çalışır */ }
}

var BASE = C.runtime.getURL('');
var HAS_OFFSCREEN = !!(C.offscreen && C.offscreen.createDocument);
var HAS_TABCAPTURE = !!(C.tabCapture && C.tabCapture.getMediaStreamId);
var ENGINE_KIND = (HAS_OFFSCREEN && HAS_TABCAPTURE) ? 'offscreen' : 'tab';
// Geliştirme/test: Chrome'da da Firefox/Safari yolunu (ekran görüntüsüyle okuma) denemek için storage.local.devEngine = 'tab'
// (oturum yokken değişirse hemen geçerli olur)
C.storage.onChanged.addListener(function (ch, area) {
  if (area !== 'local' || !ch.devEngine || S) return;
  ENGINE_KIND = (ch.devEngine.newValue === 'tab' || !(HAS_OFFSCREEN && HAS_TABCAPTURE)) ? 'tab' : 'offscreen';
});

var STYLE_DEFAULT = { size: 3.6, bg: 0, showOriginal: false };
var ENGINE_DEFAULT = { liveMode: 'auto', asrLang: 'auto', asrModel: 'base' };
var LIVE_MODES = { auto: 1, ocr: 1, speech: 1 };
var ASR_MODELS = { tiny: 1, base: 1, small: 1 };
var LANG_RE = /^(auto|[a-z]{2})$/;

var S = null;            // etkin oturum: {sid, tabId, windowId, host, fs, view, status, level, progress, startedAt, engineTab}
var loaded = null;       // oturumu depodan okuma sözü
var pending = null;      // motor açılırken bekleyen başlat komutu
var sidSeq = 0;

/* ------------------------------------------------------------------ */
/* depolama                                                            */
/* ------------------------------------------------------------------ */
function sessionArea() { return (C.storage && C.storage.session) ? C.storage.session : null; }
function loadSession() {
  if (loaded) return loaded;
  var area = sessionArea();
  var dev = C.storage.local.get('devEngine').then(function (r) { if (r && r.devEngine === 'tab') ENGINE_KIND = 'tab'; }, function () {});
  loaded = Promise.all([dev, !area ? null : area.get('as_sess').then(function (r) {
    if (!S && r && r.as_sess && typeof r.as_sess.tabId === 'number') { S = r.as_sess; sidSeq = Math.max(sidSeq, S.sid || 0); }
  }, function () { /* yok */ })]);
  return loaded;
}
function saveSession() {
  var area = sessionArea();
  if (!area) return;
  (S ? area.set({ as_sess: S }) : area.remove('as_sess')).catch(function () { /* yok */ });
}
function getLocal(keys) { return C.storage.local.get(keys).catch(function () { return {}; }); }
function setLocal(obj) { return C.storage.local.set(obj).catch(function () { /* yok */ }); }

function cleanStyle(v) {
  var s = Object.assign({}, STYLE_DEFAULT);
  if (v && typeof v === 'object') {
    var size = Number(v.size), bg = Number(v.bg);
    if (isFinite(size)) s.size = Math.min(9, Math.max(1.8, size));
    if (isFinite(bg)) s.bg = Math.min(0.9, Math.max(0, bg));
    s.showOriginal = !!v.showOriginal;
  }
  return s;
}
function cleanEngine(v) {
  var s = Object.assign({}, ENGINE_DEFAULT);
  if (v && typeof v === 'object') {
    if (LIVE_MODES[v.liveMode]) s.liveMode = v.liveMode;
    if (typeof v.asrLang === 'string' && LANG_RE.test(v.asrLang)) s.asrLang = v.asrLang;
    if (ASR_MODELS[v.asrModel]) s.asrModel = v.asrModel;
  }
  // Safari/Firefox: eklentiye sekmenin sesi verilmez; yalnızca ekrandaki altyazı (konuşma modeli boşuna inmesin)
  if (ENGINE_KIND !== 'offscreen') s.liveMode = 'ocr';
  return s;
}
function num01(v) { v = Number(v); return isFinite(v) ? Math.min(1, Math.max(0, v)) : null; }
function cleanRect(r, minW, minH) {
  if (!r || typeof r !== 'object') return null;
  var x = num01(r.x), y = num01(r.y), w = num01(r.w), h = num01(r.h);
  if (x === null || y === null || w === null || h === null) return null;
  w = Math.max(minW, Math.min(w, 1)); h = Math.max(minH, Math.min(h, 1));
  x = Math.min(x, 1 - w); y = Math.min(y, 1 - h);
  return { x: round4(x), y: round4(y), w: round4(w), h: round4(h) };
}
function cleanSub(p) {
  if (!p || typeof p !== 'object') return null;
  var cx = num01(p.cx), by = num01(p.by);
  if (cx === null || by === null) return null;
  return { cx: round4(Math.min(0.97, Math.max(0.03, cx))), by: round4(Math.min(0.99, Math.max(0.08, by))) };
}
function round4(v) { return Math.round(v * 10000) / 10000; }
function hostOf(url) { try { var u = new URL(url); return /^https?:$/.test(u.protocol) ? u.hostname : ''; } catch (e) { return ''; } }

/* ------------------------------------------------------------------ */
/* yerleşim: okuma bölgesi + Türkçe satırın yeri                        */
/* ------------------------------------------------------------------ */
function defaultLayout(fs, video, mode) {
  var region, sub;
  if (fs || !video) {
    region = { x: 0.06, y: 0.68, w: 0.88, h: 0.3 };
  } else {
    region = { x: video.x + video.w * 0.04, y: video.y + video.h * 0.6, w: video.w * 0.92, h: video.h * 0.38 };
  }
  region = cleanRect(region, 0.08, 0.05) || { x: 0.06, y: 0.68, w: 0.88, h: 0.3 };
  // Ekrandaki yazı okunurken Türkçe satır okuma bölgesinin hemen üstüne konur: üstüne binerse kendi yazımızı okuruz.
  if (mode === 'speech') sub = { cx: region.x + region.w / 2, by: Math.min(0.97, region.y + region.h * 0.85) };
  else sub = { cx: region.x + region.w / 2, by: Math.max(0.1, region.y - 0.01) };
  return { region: region, sub: cleanSub(sub), auto: true };
}
function layoutFor(host, fs, video, mode) {
  return getLocal('layouts').then(function (r) {
    var all = (r && r.layouts && typeof r.layouts === 'object') ? r.layouts : {};
    var saved = host && all[host] && all[host][fs ? 'fs' : 'n'];
    var def = defaultLayout(fs, video, mode);
    if (saved) {
      var region = cleanRect(saved.region, 0.08, 0.05), sub = cleanSub(saved.sub);
      if (region && sub) return { region: region, sub: sub, auto: false };
    }
    return def;
  });
}

/* ------------------------------------------------------------------ */
/* sekmeye ileti                                                       */
/* ------------------------------------------------------------------ */
function toTab(tabId, msg) {
  msg.to = 'overlay';
  try {
    var p = C.tabs.sendMessage(tabId, msg);
    if (p && typeof p.catch === 'function') p.catch(function () { /* katman yok (ör. chrome:// sayfası) */ });
  } catch (e) { /* yok */ }
}
function stateFor(tabId) {
  return Promise.all([getLocal(['style', 'engine']), loadSession()]).then(function (a) {
    var st = cleanStyle(a[0].style), en = cleanEngine(a[0].engine);
    if (!S || S.tabId !== tabId) return { active: false, style: st, mode: en.liveMode };
    return layoutFor(S.host, !!S.fs, S.view && S.view.video, en.liveMode).then(function (lay) {
      return { active: true, style: st, mode: en.liveMode, layout: lay, sid: S.sid };
    });
  });
}
function pushState(tabId) {
  return stateFor(tabId).then(function (st) { st.type = 'state'; toTab(tabId, st); return st; });
}

/* ------------------------------------------------------------------ */
/* motor                                                               */
/* ------------------------------------------------------------------ */
function toEngine(msg) {
  msg.to = 'engine';
  try {
    var p = C.runtime.sendMessage(msg);
    return (p && typeof p.then === 'function') ? p.catch(function () { return null; }) : Promise.resolve(null);
  } catch (e) { return Promise.resolve(null); }
}
function engineOpen() {
  if (ENGINE_KIND === 'offscreen') {
    if (C.runtime.getContexts) {
      return C.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] }).then(function (list) { return list.length > 0; }, function () { return false; });
    }
    return Promise.resolve(false);
  }
  if (!S || !S.engineTab) return Promise.resolve(false);
  return C.tabs.get(S.engineTab).then(function () { return true; }, function () { return false; });
}
function openEngine(tab) {
  if (ENGINE_KIND === 'offscreen') {
    return C.offscreen.createDocument({
      url: 'engine.html?mode=offscreen',
      reasons: ['USER_MEDIA', 'WORKERS'],
      justification: 'Sekmenin görüntüsünden altyazı okuma ve sesinden konuşma tanıma (cihazda).'
    }).catch(function (e) {
      if (/single offscreen|already/i.test(String(e && e.message))) return;
      throw e;
    });
  }
  var opts = { url: 'engine.html?mode=tab', type: 'popup', width: 440, height: 300, focused: false };
  return (C.windows && C.windows.create ? C.windows.create(opts) : C.tabs.create({ url: opts.url, active: false })).then(function (w) {
    if (S) { S.engineTab = (w && w.tabs && w.tabs[0]) ? w.tabs[0].id : (w && w.id); S.engineWin = w && w.tabs ? w.id : null; saveSession(); }
    // Pencere açılınca film sekmesi yeniden öne alınır (görünür sekme yakalanır)
    if (tab && C.windows && C.windows.update) C.windows.update(tab.windowId, { focused: true }).catch(function () {});
  });
}
function closeEngine(s) {
  if (ENGINE_KIND === 'offscreen') {
    return engineOpen().then(function (open) { if (open) return C.offscreen.closeDocument().catch(function () {}); });
  }
  if (s && s.engineWin && C.windows) return C.windows.remove(s.engineWin).catch(function () {});
  if (s && s.engineTab) return C.tabs.remove(s.engineTab).catch(function () {});
  return Promise.resolve();
}

function engineStartCmd() {
  return getLocal('engine').then(function (r) {
    var en = cleanEngine(r.engine);
    return layoutFor(S.host, !!S.fs, S.view && S.view.video, en.liveMode).then(function (lay) {
      return {
        cmd: 'start', sid: S.sid, tabId: S.tabId, windowId: S.windowId, streamId: S.streamId || null,
        settings: en, region: lay.region, viewport: S.view ? { w: S.view.w, h: S.view.h, dpr: S.view.dpr } : null
      };
    });
  });
}

function start(tabId, streamId, windowIdHint) {
  return loadSession().then(function () {
    return C.tabs.get(tabId);
  }).then(function (tab) {
    var host = hostOf(tab.url || '');
    var prev = S;
    var stopPrev = (prev && prev.tabId !== tabId) ? stop('replace') : Promise.resolve();
    return stopPrev.then(function () {
      S = {
        sid: ++sidSeq, tabId: tabId, windowId: tab.windowId || windowIdHint || null, host: host, fs: false,
        view: (prev && prev.tabId === tabId) ? prev.view : null, status: 'Başlatılıyor…', level: 'busy', progress: null,
        startedAt: Date.now(), streamId: streamId || null,
        engineTab: (prev && prev.tabId === tabId) ? prev.engineTab : null, engineWin: (prev && prev.tabId === tabId) ? prev.engineWin : null
      };
      saveSession();
      badge(tabId, true);
      // Eklenti kurulmadan önce açılmış sekmelerde katman yoktur: ekle (iki kez çalışırsa kendini atlar)
      return C.scripting.executeScript({ target: { tabId: tabId, allFrames: true }, files: ['overlay.js'] }).catch(function () { /* izin yok */ });
    }).then(function () {
      return pushState(tabId);
    }).then(function () {
      return waitView(S.sid, 1200);   // katman ekran boyunu bildirsin: kare boyu ve okuma bölgesi ona göre
    }).then(function () {
      return engineStartCmd();
    }).then(function (cmd) {
      S.streamId = null;   // akış kimliği bir kez kullanılır
      saveSession();
      return engineOpen().then(function (open) {
        if (open) return toEngine(cmd);
        pending = cmd;
        return openEngine(tab);
      });
    }).then(function () {
      return { ok: true, sid: S && S.sid, engine: ENGINE_KIND };
    });
  });
}

function waitView(sid, ms) {
  var t0 = Date.now();
  return new Promise(function (resolve) {
    (function check() {
      if (!S || S.sid !== sid || S.view || Date.now() - t0 > ms) { resolve(); return; }
      setTimeout(check, 50);
    })();
  });
}

function stop(reason) {
  return loadSession().then(function () {
    var s = S;
    if (!s) return { ok: true };
    S = null;
    pending = null;
    saveSession();
    badge(s.tabId, false);
    toTab(s.tabId, { type: 'state', active: false });
    return toEngine({ cmd: 'stop', sid: s.sid, reason: reason || 'user' }).then(function () {
      return closeEngine(s);
    }).then(function () { return { ok: true }; });
  });
}

function badge(tabId, on) {
  if (!C.action || !C.action.setBadgeText) return;
  try {
    C.action.setBadgeText({ tabId: tabId, text: on ? '●' : '' });
    if (on && C.action.setBadgeBackgroundColor) C.action.setBadgeBackgroundColor({ tabId: tabId, color: '#d23b2c' });
  } catch (e) { /* yok */ }
}

/** Ekran boyu / tam ekran / video yeri değişti → motorun okuma bölgesini güncelle */
function refreshRegion() {
  if (!S) return Promise.resolve();
  var sid = S.sid;
  return getLocal('engine').then(function (r) {
    var en = cleanEngine(r.engine);
    return layoutFor(S.host, !!S.fs, S.view && S.view.video, en.liveMode);
  }).then(function (lay) {
    if (!S || S.sid !== sid) return;
    toEngine({ cmd: 'region', sid: sid, region: lay.region, viewport: S.view ? { w: S.view.w, h: S.view.h, dpr: S.view.dpr } : null });
    return pushState(S.tabId);
  });
}

/* ------------------------------------------------------------------ */
/* iletiler                                                            */
/* ------------------------------------------------------------------ */
function fromExtensionPage(sender) {
  return sender && sender.id === C.runtime.id && typeof sender.url === 'string' && sender.url.indexOf(BASE) === 0;
}

function onPopup(msg) {
  var tabId = Number(msg.tabId);
  switch (msg.cmd) {
    case 'state':
      return Promise.all([loadSession(), getLocal(['style', 'engine'])]).then(function (a) {
        return {
          caps: { engine: ENGINE_KIND, tabCapture: ENGINE_KIND === 'offscreen', speech: ENGINE_KIND === 'offscreen' },
          style: cleanStyle(a[1].style), engine: cleanEngine(a[1].engine),
          session: S ? { tabId: S.tabId, here: S.tabId === tabId, status: S.status, level: S.level, progress: S.progress, host: S.host, fs: !!S.fs, startedAt: S.startedAt } : null
        };
      });
    case 'start':
      if (!isFinite(tabId)) return Promise.resolve({ ok: false, error: 'Sekme bulunamadı.' });
      if (ENGINE_KIND === 'offscreen' && (typeof msg.streamId !== 'string' || !msg.streamId)) {
        return Promise.resolve({ ok: false, error: 'Sekme yakalanamadı. Eklenti simgesine yeniden basıp tekrar deneyin.' });
      }
      return start(tabId, msg.streamId, Number(msg.windowId) || null).catch(function (e) {
        return stop('error').then(function () { return { ok: false, error: (e && e.message) || String(e) }; });
      });
    case 'stop':
      return stop('user');
    case 'style':
      return setLocal({ style: cleanStyle(msg.style) }).then(function () {
        return loadSession();
      }).then(function () { if (S) return pushState(S.tabId); }).then(function () { return { ok: true }; });
    case 'engine': {
      var en = cleanEngine(msg.engine);
      return setLocal({ engine: en }).then(function () { return loadSession(); }).then(function () {
        if (!S) return;
        toEngine({ cmd: 'settings', sid: S.sid, settings: en });
        return refreshRegion();
      }).then(function () { return { ok: true }; });
    }
    case 'edit':
      return loadSession().then(function () {
        if (!S || S.tabId !== tabId) return { ok: false, error: 'Önce bu sekmede çeviriyi başlatın.' };
        return pushState(tabId).then(function () { toTab(tabId, { type: 'edit', on: msg.on !== false }); return { ok: true }; });
      });
    case 'resetLayout':
      return loadSession().then(function () {
        if (!S || S.tabId !== tabId) return { ok: false };
        return getLocal('layouts').then(function (r) {
          var all = (r && r.layouts) || {};
          if (all[S.host]) { delete all[S.host][S.fs ? 'fs' : 'n']; }
          return setLocal({ layouts: all });
        }).then(refreshRegion).then(function () { return { ok: true }; });
      });
    case 'yt':
      if (!isFinite(tabId)) return Promise.resolve({ ok: false });
      return C.tabs.get(tabId).then(function (tab) {
        if (!/^https:\/\/([a-z0-9-]+\.)?youtube\.com\//.test(tab.url || '')) return { ok: false, error: 'Bu düğme YouTube sayfasında çalışır.' };
        var fn = self.AS && self.AS.ytBookmarklet;
        if (typeof fn !== 'function') return { ok: false, error: 'YouTube kısmı yüklenemedi.' };
        return C.scripting.executeScript({ target: { tabId: tabId }, world: 'MAIN', func: fn }).then(function () { return { ok: true }; });
      }).catch(function (e) { return { ok: false, error: (e && e.message) || String(e) }; });
    default:
      return Promise.resolve({ ok: false, error: 'bilinmeyen komut' });
  }
}

function onEngine(msg) {
  if (msg.type === 'hello') {
    var cmd = pending;
    pending = null;
    if (cmd && S && cmd.sid === S.sid) return Promise.resolve(cmd);
    return Promise.resolve(null);
  }
  return loadSession().then(function () {
    if (!S || msg.sid !== S.sid) return null;   // eski oturumdan kalan ileti
    switch (msg.type) {
      case 'lines': {
        var lines = Array.isArray(msg.lines) ? msg.lines.slice(-3).map(function (l) {
          return { tr: String((l && l.tr) || '').slice(0, 600), src: String((l && l.src) || '').slice(0, 600), kind: String((l && l.kind) || '') };
        }) : [];
        toTab(S.tabId, { type: 'lines', lines: lines, sid: S.sid });
        return null;
      }
      case 'status':
        S.status = String(msg.text || '').slice(0, 400);
        S.level = String(msg.level || 'info');
        saveSession();
        return null;
      case 'progress':
        S.progress = msg.done ? null : { label: String(msg.label || '').slice(0, 120), loaded: Number(msg.loaded) || 0, total: Number(msg.total) || 0 };
        saveSession();
        return null;
      case 'started':
        return refreshRegion();   // motor hazır olmadan gelen ölçüler kaybolmasın
      case 'ended':
        S.status = String(msg.text || 'Çeviri durdu.').slice(0, 400);
        return stop('ended');
      default:
        return null;
    }
  });
}

function onOverlay(msg, sender) {
  var tab = sender.tab;
  if (!tab || typeof tab.id !== 'number') return Promise.resolve(null);
  var top = sender.frameId === 0;
  switch (msg.type) {
    case 'hello':
      return stateFor(tab.id);
    case 'view':
      if (!top) return Promise.resolve(null);
      return loadSession().then(function () {
        if (!S || S.tabId !== tab.id) return null;
        var w = Number(msg.w), h = Number(msg.h), dpr = Number(msg.dpr);
        if (!(w > 0 && h > 0)) return null;
        var host = hostOf(tab.url || '') || S.host;
        var video = cleanRect(msg.video, 0.02, 0.02);
        var changed = !S.view || S.fs !== !!msg.fs || S.host !== host || Math.abs(S.view.w - w) > 2 || Math.abs(S.view.h - h) > 2 ||
          JSON.stringify(S.view.video || null) !== JSON.stringify(video || null);
        S.view = { w: Math.round(w), h: Math.round(h), dpr: isFinite(dpr) && dpr > 0 ? Math.min(4, dpr) : 1, video: video };
        S.fs = !!msg.fs;
        S.host = host;
        saveSession();
        if (changed) return refreshRegion();
        return null;
      });
    case 'saveLayout':
      return loadSession().then(function () {
        if (!S || S.tabId !== tab.id || !S.host) return { ok: false };
        var region = cleanRect(msg.region, 0.08, 0.05), sub = cleanSub(msg.sub);
        if (!region || !sub) return { ok: false };
        var fs = !!msg.fs;
        return getLocal('layouts').then(function (r) {
          var all = (r && r.layouts && typeof r.layouts === 'object') ? r.layouts : {};
          var hosts = Object.keys(all);
          if (!all[S.host] && hosts.length >= 200) delete all[hosts[0]];   // sınırsız büyümesin
          all[S.host] = all[S.host] || {};
          all[S.host][fs ? 'fs' : 'n'] = { region: region, sub: sub };
          return setLocal({ layouts: all });
        }).then(refreshRegion).then(function () { return { ok: true }; });
      });
    case 'resetLayout':
      return loadSession().then(function () {
        if (!S || S.tabId !== tab.id || !S.host) return { ok: false };
        var fs = !!msg.fs;
        return getLocal('layouts').then(function (r) {
          var all = (r && r.layouts && typeof r.layouts === 'object') ? r.layouts : {};
          if (all[S.host]) delete all[S.host][fs ? 'fs' : 'n'];
          return setLocal({ layouts: all });
        }).then(refreshRegion).then(function () { return { ok: true }; });
      });
    default:
      return Promise.resolve(null);
  }
}

C.runtime.onMessage.addListener(function (msg, sender, reply) {
  if (!msg || typeof msg !== 'object') return false;
  var p = null;
  if (msg.from === 'overlay') {
    if (sender.id !== C.runtime.id || !sender.tab) return false;
    p = onOverlay(msg, sender);
  } else if (msg.from === 'engine') {
    if (!fromExtensionPage(sender)) return false;
    p = onEngine(msg);
  } else if (msg.to === 'bg') {
    if (!fromExtensionPage(sender)) return false;
    p = onPopup(msg);
  } else {
    return false;
  }
  p.then(function (r) { reply(r === undefined ? null : r); }, function (e) { reply({ ok: false, error: (e && e.message) || String(e) }); });
  return true;
});

C.tabs.onRemoved.addListener(function (tabId) {
  loadSession().then(function () {
    if (S && S.tabId === tabId) stop('tab-closed');
    else if (S && S.engineTab === tabId) { S.status = 'Çeviri penceresi kapatıldı.'; stop('engine-closed'); }
  });
});
if (C.runtime.onStartup) C.runtime.onStartup.addListener(function () { S = null; saveSession(); });
