/* Altyazı Şefi eklentisi: sayfadaki Türkçe altyazı katmanı (içerik betiği, her çerçevede).
 *
 * Çeviri bu sekmede başlatılmadıkça hiçbir şey yapmaz (yalnızca açılışta arka plana "etkin miyim?" diye sorar).
 * Etkinken:
 *   - Türkçe satırları videonun üstünde, şeffaf zeminde gösterir. Satırları yalnızca "gösteren çerçeve" çizer:
 *     tam ekran yoksa en üst sayfa; tam ekran varsa tam ekrana geçen öğenin bulunduğu çerçeve (oynatıcı başka
 *     bir sitenin çerçevesindeyse o çerçeve). Katman "popover" olarak en üst katmana konur; tam ekrana geçilince
 *     yeniden açılarak tam ekran öğesinin de üstüne çıkar (tam ekrandaki <video>'nun bile üstünde görünür).
 *   - En üst sayfa ekran boyunu, tam ekran durumunu ve en büyük videonun yerini arka plana bildirir; okuma bölgesi
 *     buna göre ayarlanır.
 *   - "Altyazı yerini ayarla" açılınca gösteren çerçevede iki kutu çıkar: yabancı altyazının okunacağı bölge ve
 *     Türkçe satırın yeri. Sürüklenir, boyutlandırılır, site için (tam ekran ve normal ayrı) kaydedilir.
 * Güvenlik: sayfanın DOM'una tek bir kapalı gölge kök (shadow root) eklenir; metin yalnızca textContent ile yazılır;
 * sayfadan hiçbir veri okunmaz (yalnızca video kutularının boyu ve yeri). Sayfanın kodu bu betiği göremez. */
(function () {
  'use strict';
  if (window.__altyaziSefiKatman) return;
  window.__altyaziSefiKatman = true;
  var C = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) ? chrome
    : (typeof browser !== 'undefined' && browser.runtime && browser.runtime.id ? browser : null);
  if (!C) return;

  var TOP = (function () { try { return window.top === window; } catch (e) { return false; } })();
  var D = document;
  var POPOVER = typeof HTMLElement !== 'undefined' && typeof HTMLElement.prototype.showPopover === 'function';
  var SAMPLE = 'Türkçe altyazı burada görünür';

  var st = { active: false, sid: 0, lines: [], style: { size: 3.6, bg: 0, showOriginal: false }, layout: null, mode: 'auto' };
  var ui = null;        // {host, root, wrap, edit...}
  var edit = null;      // düzenleme durumu
  var viewTimer = null, lastView = '';

  /* ---------------- yardımcılar ---------------- */
  function send(m) {
    m.from = 'overlay';
    try {
      var p = C.runtime.sendMessage(m);
      return (p && typeof p.then === 'function') ? p.catch(function () { return null; }) : Promise.resolve(null);
    } catch (e) { return Promise.resolve(null); }   // eklenti yeniden yüklendi: bu betik artık yetim
  }
  function fsEl() { return D.fullscreenElement || D.webkitFullscreenElement || null; }
  /** Satırları bu çerçeve mi çizer? */
  function isDisplay() {
    var f = fsEl();
    if (f) return !/^(IFRAME|FRAME)$/.test(f.tagName);
    return TOP;
  }
  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function pct(v) { return (Math.round(v * 100000) / 1000) + '%'; }
  function el(tag, cls, text) {
    var n = D.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = String(text);
    return n;
  }

  /* ---------------- görünüm ---------------- */
  var CSS = [
    ':host{all:initial}',
    '.wrap{position:absolute;transform:translateX(-50%);max-width:94%;display:flex;flex-direction:column;align-items:center;gap:.12em;',
    'font:600 var(--as-size,3.6vh)/1.25 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;text-align:center;color:#fff;pointer-events:none}',
    '.ln{display:block;max-width:100%}',
    '.ln span{display:inline;padding:.04em .32em;border-radius:.18em;background:rgba(0,0,0,var(--as-bg,0));white-space:pre-wrap;',
    '-webkit-box-decoration-break:clone;box-decoration-break:clone;',
    'text-shadow:0 0 2px #000,0 0 3px #000,1px 1px 2px #000,-1px -1px 2px #000,1px -1px 2px #000,-1px 1px 2px #000}',
    '.ln .src{font-size:.6em;font-weight:500;opacity:.9}',
    '.wrap.editing{pointer-events:auto;cursor:move;outline:2px dashed #ffd24a;outline-offset:6px;border-radius:4px}',
    '.box{position:absolute;box-sizing:border-box;border:2px dashed #ffd24a;background:rgba(255,210,74,.12);pointer-events:auto;cursor:move;border-radius:4px}',
    '.box b{position:absolute;left:6px;top:4px;font:600 13px/1.3 system-ui,sans-serif;color:#111;background:#ffd24a;padding:2px 6px;border-radius:3px;pointer-events:none}',
    '.grip{position:absolute;right:-7px;bottom:-7px;width:16px;height:16px;background:#ffd24a;border:2px solid #111;border-radius:3px;cursor:nwse-resize}',
    '.bar{position:absolute;left:50%;top:12px;transform:translateX(-50%);display:flex;flex-wrap:wrap;align-items:center;gap:8px;',
    'max-width:calc(100% - 24px);box-sizing:border-box;padding:10px 12px;border-radius:10px;background:rgba(17,20,28,.94);color:#fff;',
    'font:500 14px/1.35 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;pointer-events:auto;box-shadow:0 6px 24px rgba(0,0,0,.4)}',
    '.bar p{margin:0;flex:1 1 260px}',
    '.bar button{font:600 14px system-ui,sans-serif;padding:7px 12px;border-radius:7px;border:0;cursor:pointer;background:#2b3245;color:#fff}',
    '.bar button.ok{background:#ffb43a;color:#1a1a1a}',
    '.bar button:focus-visible{outline:2px solid #fff;outline-offset:2px}'
  ].join('');

  function build() {
    if (ui) return ui;
    var host = D.createElement('div');
    host.setAttribute('data-altyazi-sefi', '');
    if (POPOVER) host.setAttribute('popover', 'manual');
    var s = host.style;
    var imp = function (k, v) { s.setProperty(k, v, 'important'); };
    imp('position', 'fixed'); imp('inset', '0'); imp('width', '100%'); imp('height', '100%');
    imp('max-width', 'none'); imp('max-height', 'none'); imp('margin', '0'); imp('padding', '0'); imp('border', '0');
    imp('background', 'transparent'); imp('overflow', 'visible'); imp('pointer-events', 'none');
    imp('z-index', '2147483647'); imp('display', 'none'); imp('opacity', '1'); imp('transform', 'none');
    imp('color-scheme', 'normal'); imp('filter', 'none'); imp('visibility', 'visible');
    var root = host.attachShadow({ mode: 'closed' });
    var styled = false;
    try {
      if (typeof CSSStyleSheet === 'function' && 'adoptedStyleSheets' in root) {
        var sheet = new CSSStyleSheet();
        sheet.replaceSync(CSS);
        root.adoptedStyleSheets = [sheet];
        styled = true;
      }
    } catch (e) { styled = false; }
    if (!styled) root.appendChild(el('style', null, CSS));
    var wrap = el('div', 'wrap');
    root.appendChild(wrap);
    ui = { host: host, root: root, wrap: wrap };
    return ui;
  }

  function place() {
    var u = build();
    var host = u.host;
    var f = fsEl();
    var parent = D.documentElement;
    if (!POPOVER && f && !/^(VIDEO|IFRAME|FRAME|IMG|CANVAS|OBJECT|EMBED)$/.test(f.tagName)) parent = f;
    if (!parent) return;
    if (host.parentNode !== parent) parent.appendChild(host);
    host.style.setProperty('display', 'block', 'important');
    if (POPOVER) {
      try {
        // Yeniden açmak, en üst katmanda tam ekran öğesinin de üstüne çıkarır
        if (host.matches(':popover-open')) host.hidePopover();
        host.showPopover();
      } catch (e) { /* belge görünmüyor olabilir */ }
    }
  }
  function hide() {
    if (!ui) return;
    try { if (POPOVER && ui.host.matches(':popover-open')) ui.host.hidePopover(); } catch (e) { /* yok */ }
    ui.host.style.setProperty('display', 'none', 'important');
  }
  function remove() {
    stopEdit(false);
    if (!ui) return;
    hide();
    if (ui.host.parentNode) ui.host.parentNode.removeChild(ui.host);
    ui = null;
  }

  function applyStyle() {
    if (!ui) return;
    var s = st.style || {};
    ui.wrap.style.setProperty('--as-size', clamp(Number(s.size) || 3.6, 1.8, 9) + 'vh');
    ui.wrap.style.setProperty('--as-bg', String(clamp(Number(s.bg) || 0, 0, 0.9)));
    var sub = (edit && edit.sub) || (st.layout && st.layout.sub) || { cx: 0.5, by: 0.9 };
    ui.wrap.style.left = pct(sub.cx);
    ui.wrap.style.bottom = pct(1 - sub.by);
    ui.wrap.style.top = 'auto';
  }

  function render() {
    if (!st.active || !isDisplay()) { if (ui && !edit) hide(); return; }
    var u = build();
    if (!u.host.isConnected || u.host.style.getPropertyValue('display') === 'none') place();
    applyStyle();
    var w = u.wrap;
    while (w.firstChild) w.removeChild(w.firstChild);
    var lines = st.lines || [];
    if (edit && !lines.length) lines = [{ tr: SAMPLE, src: '' }];
    for (var i = 0; i < lines.length; i++) {
      var L = lines[i];
      var tr = String((L && L.tr) || '').slice(0, 600);
      if (!tr) continue;
      var ln = el('div', 'ln');
      ln.appendChild(el('span', 'tr', tr));
      var src = String((L && L.src) || '').slice(0, 600);
      if (st.style && st.style.showOriginal && src && src !== tr) {
        ln.appendChild(D.createElement('br'));
        ln.appendChild(el('span', 'src', src));
      }
      w.appendChild(ln);
    }
    w.classList.toggle('editing', !!edit);
  }

  /* ---------------- en üst sayfa: ölçüler ---------------- */
  function visibleRect(n, vw, vh) {
    var r = n.getBoundingClientRect();
    var x1 = Math.max(0, r.left), y1 = Math.max(0, r.top), x2 = Math.min(vw, r.right), y2 = Math.min(vh, r.bottom);
    if (x2 <= x1 || y2 <= y1) return null;
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1, a: (x2 - x1) * (y2 - y1) };
  }
  function mainVideo() {
    var vw = window.innerWidth, vh = window.innerHeight;
    if (!(vw > 0 && vh > 0)) return null;
    var best = null;
    var pick = function (list, minFrac) {
      for (var i = 0; i < list.length; i++) {
        var r = visibleRect(list[i], vw, vh);
        if (r && r.a >= minFrac * vw * vh && (!best || r.a > best.a)) best = r;
      }
    };
    pick(D.getElementsByTagName('video'), 0.02);
    if (!best) pick(D.getElementsByTagName('iframe'), 0.08);   // oynatıcı başka sitenin çerçevesinde
    if (!best) return null;
    return { x: best.x / vw, y: best.y / vh, w: best.w / vw, h: best.h / vh };
  }
  function reportView(force) {
    if (!TOP || !st.active) return;
    var v = mainVideo();
    var m = { type: 'view', fs: !!fsEl(), w: window.innerWidth, h: window.innerHeight, dpr: window.devicePixelRatio || 1, video: v };
    var key = JSON.stringify([m.fs, m.w, m.h, v && [v.x, v.y, v.w, v.h].map(function (n) { return Math.round(n * 200); })]);
    if (!force && key === lastView) return;
    lastView = key;
    send(m);
  }
  function startViewTimer() {
    if (!TOP || viewTimer) return;
    viewTimer = setInterval(function () { reportView(false); }, 1000);   // kaydırma, oynatıcı büyümesi
  }
  function stopViewTimer() { if (viewTimer) { clearInterval(viewTimer); viewTimer = null; } lastView = ''; }

  /* ---------------- durum ---------------- */
  function applyState(m) {
    if (!m) return;
    var was = st.active;
    st.active = !!m.active;
    if (!st.active) {
      st.lines = [];
      st.sid = 0;
      stopViewTimer();
      remove();
      return;
    }
    if (m.sid && m.sid !== st.sid) { st.sid = m.sid; st.lines = []; }
    if (m.style) st.style = m.style;
    if (m.layout) st.layout = m.layout;
    if (m.mode) st.mode = m.mode;
    if (!was) { reportView(true); startViewTimer(); }
    if (edit) layoutEdit();
    render();
  }

  /* ---------------- düzenleme: bölge ve satır yeri ---------------- */
  function startEdit() {
    if (!st.active || !isDisplay() || edit) return;
    var lay = st.layout || {};
    var region = lay.region || { x: 0.06, y: 0.68, w: 0.88, h: 0.3 };
    var sub = lay.sub || { cx: 0.5, by: 0.66 };
    var u = build();
    edit = { region: { x: region.x, y: region.y, w: region.w, h: region.h }, sub: { cx: sub.cx, by: sub.by }, fs: !!fsEl(), nodes: [] };
    var showRegion = st.mode !== 'speech';
    if (showRegion) {
      var box = el('div', 'box');
      box.appendChild(el('b', null, 'Yabancı altyazı burada okunur'));
      var grip = el('div', 'grip');
      box.appendChild(grip);
      u.root.appendChild(box);
      edit.box = box;
      edit.nodes.push(box);
      drag(box, function (dx, dy, s) {
        edit.region.x = clamp(s.x + dx, 0, 1 - edit.region.w);
        edit.region.y = clamp(s.y + dy, 0, 1 - edit.region.h);
        layoutEdit();
      }, function () { return { x: edit.region.x, y: edit.region.y }; });
      drag(grip, function (dx, dy, s) {
        edit.region.w = clamp(s.w + dx, 0.08, 1 - edit.region.x);
        edit.region.h = clamp(s.h + dy, 0.05, 1 - edit.region.y);
        layoutEdit();
      }, function () { return { w: edit.region.w, h: edit.region.h }; });
    }
    drag(u.wrap, function (dx, dy, s) {
      edit.sub.cx = clamp(s.cx + dx, 0.03, 0.97);
      edit.sub.by = clamp(s.by + dy, 0.08, 0.99);
      applyStyle();
    }, function () { return { cx: edit.sub.cx, by: edit.sub.by }; });

    var bar = el('div', 'bar');
    bar.appendChild(el('p', null, showRegion
      ? 'Sarı kutuyu filmin kendi altyazısının çıktığı yere, Türkçe satırı da istediğiniz yere sürükleyin. İkisi üst üste gelmesin.'
      : 'Türkçe satırı istediğiniz yere sürükleyin.'));
    var save = el('button', 'ok', 'Kaydet');
    var reset = el('button', null, 'Varsayılan');
    var cancel = el('button', null, 'Vazgeç');
    save.type = reset.type = cancel.type = 'button';
    bar.appendChild(save); bar.appendChild(reset); bar.appendChild(cancel);
    u.root.appendChild(bar);
    edit.nodes.push(bar);
    save.addEventListener('click', function () {
      var m = { type: 'saveLayout', fs: edit.fs, region: edit.region, sub: edit.sub };
      stopEdit(true, m);
    });
    reset.addEventListener('click', function () { stopEdit(false); send({ type: 'resetLayout', fs: !!fsEl() }); });
    cancel.addEventListener('click', function () { stopEdit(false); });
    edit.onKey = function (e) { if (e.key === 'Escape') { e.stopPropagation(); stopEdit(false); } };
    window.addEventListener('keydown', edit.onKey, true);
    place();
    layoutEdit();
    render();
    try { save.focus({ preventScroll: true }); } catch (e) { /* */ }
  }
  function layoutEdit() {
    if (!edit) return;
    if (edit.box) {
      var r = edit.region, b = edit.box.style;
      b.left = pct(r.x); b.top = pct(r.y); b.width = pct(r.w); b.height = pct(r.h);
    }
    applyStyle();
  }
  function stopEdit(saveIt, m) {
    if (!edit) return;
    var e = edit;
    edit = null;
    window.removeEventListener('keydown', e.onKey, true);
    e.nodes.forEach(function (n) { if (n.parentNode) n.parentNode.removeChild(n); });
    if (saveIt && m) {
      st.layout = { region: m.region, sub: m.sub, auto: false };   // hemen yeni yerde göster
      send(m);
    }
    render();
  }
  /** Sürükleme: onMove(dx, dy, başlangıç) kesir cinsinden */
  function drag(node, onMove, snapshot) {
    node.addEventListener('pointerdown', function (ev) {
      if (!edit || ev.button !== 0) return;
      ev.preventDefault();
      ev.stopPropagation();
      var vw = window.innerWidth || 1, vh = window.innerHeight || 1;
      var x0 = ev.clientX, y0 = ev.clientY, s0 = snapshot();
      try { node.setPointerCapture(ev.pointerId); } catch (e) { /* */ }
      var move = function (e) { e.preventDefault(); onMove((e.clientX - x0) / vw, (e.clientY - y0) / vh, s0); };
      var up = function () {
        node.removeEventListener('pointermove', move);
        node.removeEventListener('pointerup', up);
        node.removeEventListener('pointercancel', up);
      };
      node.addEventListener('pointermove', move);
      node.addEventListener('pointerup', up);
      node.addEventListener('pointercancel', up);
    });
  }

  /* ---------------- olaylar ---------------- */
  C.runtime.onMessage.addListener(function (m) {
    if (!m || m.to !== 'overlay') return;
    if (m.type === 'state') applyState(m);
    else if (m.type === 'lines') {
      if (!st.active || (m.sid && m.sid !== st.sid)) return;
      st.lines = Array.isArray(m.lines) ? m.lines.slice(-3) : [];
      render();
    } else if (m.type === 'edit') {
      if (m.on) startEdit(); else stopEdit(false);
    }
  });

  function onFs() {
    if (edit) stopEdit(false);   // tam ekran değişince yerler de değişir
    if (st.active && isDisplay()) place(); else if (ui) hide();
    render();
    reportView(true);
  }
  D.addEventListener('fullscreenchange', onFs);
  D.addEventListener('webkitfullscreenchange', onFs);
  var rt = null;
  window.addEventListener('resize', function () {
    if (!st.active) return;
    clearTimeout(rt);
    rt = setTimeout(function () { reportView(false); if (edit) layoutEdit(); }, 250);
  });

  send({ type: 'hello', top: TOP }).then(function (m) { if (m && m.active) applyState(m); });

  // Testler için: yalnızca eklentinin yalıtılmış dünyasında görünür, sayfanın kodu erişemez
  window.__asKatmanTest = function () {
    var shown = [];
    if (ui) for (var i = 0; i < ui.wrap.children.length; i++) shown.push(ui.wrap.children[i].textContent);
    var r = ui ? ui.wrap.getBoundingClientRect() : null;
    return {
      active: st.active, display: isDisplay(), top: TOP, lines: shown, edit: !!edit, layout: st.layout, style: st.style,
      sub: edit ? edit.sub : (st.layout && st.layout.sub) || null,
      connected: !!(ui && ui.host.isConnected), shownHost: !!(ui && ui.host.style.getPropertyValue('display') === 'block'),
      popoverOpen: !!(ui && POPOVER && ui.host.matches(':popover-open')),
      rect: r ? { x: r.x, y: r.y, w: r.width, h: r.height } : null, vw: window.innerWidth, vh: window.innerHeight
    };
  };
  window.__asKatmanTestDrag = function (which, dx, dy) {
    // Düzenleme kutularını sürükler (gerçek işaretçi olayları sayfa sınırında tutarsız olabildiği için)
    if (!edit) return false;
    if (which === 'region' && edit.region) { edit.region.x = clamp(edit.region.x + dx, 0, 1 - edit.region.w); edit.region.y = clamp(edit.region.y + dy, 0, 1 - edit.region.h); }
    if (which === 'sub') { edit.sub.cx = clamp(edit.sub.cx + dx, 0.03, 0.97); edit.sub.by = clamp(edit.sub.by + dy, 0.08, 0.99); }
    layoutEdit();
    return true;
  };
})();
