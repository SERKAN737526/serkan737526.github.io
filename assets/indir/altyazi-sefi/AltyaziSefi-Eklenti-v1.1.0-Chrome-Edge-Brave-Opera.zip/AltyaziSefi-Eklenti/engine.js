/* Altyazı Şefi eklentisi: çeviri motoru (engine.html).
 *
 * Sitenin Canlı çeviri motoru (js/live.js + ocr, asr, translate, assembler, subs) burada olduğu gibi çalışır;
 * yalnızca görüntü/ses kaynağı ve çıktı yeri değişir:
 *   - Chrome/Edge ("offscreen" belge, görünmez): arka planın verdiği chrome.tabCapture akış kimliğiyle sekmenin
 *     görüntüsü ve sesi alınır. Ses yakalanınca sekme sessizleşir; bu yüzden ses burada kullanıcıya geri çalınır.
 *   - Firefox/Safari (küçük eklenti penceresi): tabs.captureVisibleTab ile sekmenin görünen hâli saniyede birkaç kez
 *     alınıp bir tuval akışına çizilir. Ses yoktur: yalnızca ekrandaki altyazı okunur.
 * Türkçe satırlar (AS.subs'ın gösterdiği satırların tamamı) arka plana, oradan sekmedeki katmana gider.
 * Okuma bölgesi sekmenin görünen alanına göre (kesir) gelir; yakalanan karede kenar boşluğu (siyah bant) varsa
 * buna göre çevrilir. Kilit: geçerli etkinleştirme kodu yoksa başlamaz (site ile aynı doğrulama). */
(function () {
  'use strict';
  var C = (typeof chrome !== 'undefined' && chrome.runtime) ? chrome : browser;
  var AS = window.AS;
  var KIND = new URLSearchParams(location.search).get('mode') === 'tab' ? 'tab' : 'offscreen';
  var U = AS.util;

  var cur = null;          // {sid, tabId, windowId, stream, actx, grab, viewport, region}
  var statusEl = document.getElementById('eng-status');
  var stopBtn = document.getElementById('eng-stop');

  /* ---------------- arka plana ileti ---------------- */
  function send(m) {
    m.from = 'engine';
    m.sid = cur ? cur.sid : 0;
    try {
      var p = C.runtime.sendMessage(m);
      if (p && typeof p.catch === 'function') p.catch(function () { /* arka plan uyuyor olabilir */ });
    } catch (e) { /* yok */ }
  }
  function status(text, level) {
    if (statusEl) statusEl.textContent = text;
    if (cur) send({ type: 'status', text: text, level: level || 'info' });
  }

  /* ---------------- site motorunu kur ---------------- */
  var panel = document.getElementById('panel');
  var stage = document.getElementById('stage');
  AS.modes.live.mount(panel);
  AS.subs.attach(stage);

  // Sitenin durum iletileri sitedeki düğmelere göre yazılmış; eklentide anlamlı olanlara çevrilir.
  AS.bus.on('status', function (s) {
    if (!cur || !s || (s.mode !== 'live' && s.mode !== 'app')) return;
    var t = String(s.text || '');
    var m = /^Paylaşım başladı: ([^.]*)\./.exec(t);
    if (m) { status('Çeviri başladı: ' + m[1] + '.', 'ok'); return; }
    if (/^Paylaşım durduruldu|^Canlı çeviri durduruldu/.test(t)) return;
    if (/^Ses paylaşılmadı/.test(t)) {
      status(KIND === 'tab' ? 'Bu tarayıcı eklentiye sekmenin sesini vermiyor: yalnızca ekrandaki altyazı okunuyor.'
        : 'Sekmenin sesi alınamadı: yalnızca ekrandaki altyazı okunuyor.', 'warn');
      return;
    }
    if (/Altyazı penceresi/.test(t)) return;
    status(t, s.level);
  });
  var lastProg = 0;
  AS.bus.on('progress', function (p) {
    if (!cur || !p) return;
    var now = Date.now();
    if (!p.done && now - lastProg < 400) return;
    lastProg = now;
    send({ type: 'progress', what: p.what, label: p.label, loaded: p.loaded, total: p.total, done: !!p.done });
  });

  // AS.subs ekrana ne çizerse (satır geldi, değişti, süresi doldu) aynısı sekmeye gider.
  var lastKey = '';
  function pushLines() {
    if (!cur) return;
    var lines = AS.subs.current();
    var key = JSON.stringify(lines);
    if (key === lastKey) return;
    lastKey = key;
    send({ type: 'lines', lines: lines });
  }
  new MutationObserver(pushLines).observe(stage, { subtree: true, childList: true, characterData: true, attributes: true });

  /* ---------------- ayarlar ---------------- */
  function applySettings(st) {
    if (!st) return;
    if (st.liveMode) AS.settings.set('liveMode', st.liveMode);
    if (st.asrLang) AS.settings.set('asrLang', st.asrLang);
    if (st.asrModel) AS.settings.set('asrModel', st.asrModel);
  }

  /** Görünen alanın kesirleri → yakalanan karenin kesirleri (oranlar farklıysa ortalanmış bantlar varsayılır) */
  function frameRegion(r, vp, fw, fh) {
    if (!r) return null;
    if (!vp || !(vp.w > 0) || !(vp.h > 0) || !(fw > 0) || !(fh > 0)) return r;
    var va = vp.w / vp.h, fa = fw / fh, ox = 0, oy = 0, sx = 1, sy = 1;
    if (Math.abs(va - fa) / va > 0.01) {
      if (fa > va) { sx = va / fa; ox = (1 - sx) / 2; } else { sy = fa / va; oy = (1 - sy) / 2; }
    }
    return { x: ox + r.x * sx, y: oy + r.y * sy, w: r.w * sx, h: r.h * sy };
  }
  function frameSize() {
    var t = cur && cur.stream && cur.stream.getVideoTracks()[0];
    if (!t) return null;
    var s = t.getSettings ? t.getSettings() : {};
    return (s.width > 0 && s.height > 0) ? { w: s.width, h: s.height } : null;
  }
  function applyRegion() {
    if (!cur || !cur.region) return;
    var fsz = frameSize();
    var r = frameRegion(cur.region, cur.viewport, fsz && fsz.w, fsz && fsz.h);
    var q = function (v) { return Math.round(v * 10000) / 10000; };
    AS.settings.set('ocrRegion', { x: q(r.x), y: q(r.y), w: q(r.w), h: q(r.h) });
    cur.appliedFor = fsz ? fsz.w + 'x' + fsz.h : '';
  }

  /* ---------------- kilit ---------------- */
  function unlocked() {
    var code = null;
    try { code = localStorage.getItem('as.lock.code'); } catch (e) { code = null; }
    if (!code || !AS.lock || !AS.lock._check) return Promise.resolve(false);
    return AS.lock._check(code).then(function (r) { return !!(r && r.ok); }, function () { return false; });
  }

  /* ---------------- kaynaklar ---------------- */
  function tabStream(streamId, vp) {
    var md = navigator.mediaDevices;
    if (!md || !md.getUserMedia) return Promise.reject(new Error('Bu tarayıcı sekmeyi yakalayamıyor.'));
    // Kare boyu görünen alanın oranında istenir (siyah bant olmasın), en çok 1920 px genişlik
    var w = 1920, h = 1080;
    if (vp && vp.w > 0 && vp.h > 0) {
      var dpr = vp.dpr > 0 ? vp.dpr : 1;
      w = Math.min(1920, Math.round(vp.w * dpr));
      h = Math.max(120, Math.round(w * vp.h / vp.w));
      if (h > 1920) { h = 1920; w = Math.round(h * vp.w / vp.h); }
    }
    var src = { chromeMediaSource: 'tab', chromeMediaSourceId: streamId };
    return md.getUserMedia({
      audio: { mandatory: src },
      video: { mandatory: Object.assign({ maxWidth: w, maxHeight: h, maxFrameRate: 10 }, src) }
    });
  }

  /** Firefox/Safari: görünen sekmenin görüntüsü → tuval akışı */
  function grabStream(c) {
    var canvas = document.createElement('canvas');
    canvas.width = 1280; canvas.height = 720;
    var ctx = canvas.getContext('2d', { alpha: false });
    var stream = canvas.captureStream ? canvas.captureStream(0) : null;
    if (!stream) return Promise.reject(new Error('Bu tarayıcıda ekran görüntüsünden okuma yapılamıyor.'));
    var track = stream.getVideoTracks()[0];
    var busy = false, dead = false, fails = 0, warned = false;
    var tick = function () {
      if (dead || busy) return;
      busy = true;
      C.tabs.get(c.tabId).then(function (tab) {
        if (!tab || !tab.active) return null;     // film sekmesi önde değilse başka sekmeyi okumayalım
        return C.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 85 });
      }).then(function (url) {
        if (!url || dead) return null;
        return fetch(url).then(function (r) { return r.blob(); }).then(function (b) { return createImageBitmap(b); });
      }).then(function (bmp) {
        if (!bmp) return;
        if (dead) { bmp.close(); return; }
        if (canvas.width !== bmp.width || canvas.height !== bmp.height) { canvas.width = bmp.width; canvas.height = bmp.height; }
        ctx.drawImage(bmp, 0, 0);
        bmp.close();
        if (track && typeof track.requestFrame === 'function') track.requestFrame();
        fails = 0;
      }).catch(function () {
        fails++;
        if (fails >= 6 && !warned) { warned = true; status('Sekmenin görüntüsü alınamıyor. Film sekmesi açık ve önde olmalı.', 'warn'); }
      }).then(function () { busy = false; });
    };
    var timer = setInterval(tick, 600);   // tarayıcılar saniyede en çok 2 görüntüye izin veriyor
    tick();
    c.grab = { stop: function () { dead = true; clearInterval(timer); } };
    return Promise.resolve(stream);
  }

  /* ---------------- oturum ---------------- */
  function start(cmd) {
    stop();
    var c = {
      sid: cmd.sid, tabId: cmd.tabId, windowId: cmd.windowId, stream: null, actx: null, grab: null,
      viewport: cmd.viewport || null, region: cmd.region || null, appliedFor: ''
    };
    cur = c;
    applySettings(cmd.settings);
    status('Başlatılıyor…', 'busy');
    return unlocked().then(function (ok) {
      if (!ok) throw new Error('Eklenti kilitli. Eklenti simgesine basıp etkinleştirme kodunu girin.');
      if (KIND === 'offscreen') {
        if (!cmd.streamId) throw new Error('Sekme yakalanamadı. Eklenti simgesine yeniden basıp tekrar deneyin.');
        return tabStream(cmd.streamId, cmd.viewport);
      }
      return grabStream(c);
    }).then(function (stream) {
      if (cur !== c) { stream.getTracks().forEach(function (t) { t.stop(); }); return null; }
      c.stream = stream;
      if (stream.getAudioTracks().length) {
        // Sekme yakalanınca kendi sesi kısılır: kullanıcı duymaya devam etsin
        try {
          var AC = window.AudioContext || window.webkitAudioContext;
          c.actx = new AC();
          c.actx.createMediaStreamSource(stream).connect(c.actx.destination);
        } catch (e) { c.actx = null; }
      }
      stream.getTracks().forEach(function (t) {
        t.addEventListener('ended', function () {
          if (cur !== c) return;
          var live = stream.getTracks().some(function (x) { return x.readyState === 'live'; });
          if (!live) { send({ type: 'ended', text: 'Sekmenin yakalanması bitti (sekme kapandı ya da başka bir yakalama başladı).' }); stop(); }
        });
      });
      applyRegion();
      return AS.modes.live.startWithStream(stream);
    }).then(function (info) {
      if (!info || cur !== c) return { ok: false };
      send({ type: 'started' });
      return { ok: true, info: info };
    }, function (e) {
      var msg = (e && e.message) || String(e);
      if (cur === c) { status(msg, 'error'); send({ type: 'ended', text: msg }); stop(); }
      return { ok: false, error: msg };
    });
  }

  function stop() {
    var c = cur;
    if (!c) return;
    cur = null;
    try { AS.modes.live.stop(); } catch (e) { /* yok */ }
    if (c.grab) c.grab.stop();
    if (c.stream) c.stream.getTracks().forEach(function (t) { try { t.stop(); } catch (e) { /* */ } });
    if (c.actx) { try { c.actx.close(); } catch (e) { /* */ } }
    try { AS.subs.clear(); } catch (e) { /* */ }
    lastKey = '';
    if (statusEl) statusEl.textContent = 'Durdu.';
  }

  /** Tanı için: o anki karenin küçük bir görüntüsü (yalnızca eklentinin kendi sayfalarından istenebilir) */
  function snap() {
    if (!cur || !cur.stream) return Promise.resolve({ ok: false });
    var v = document.createElement('video');
    v.muted = true;
    v.srcObject = new MediaStream(cur.stream.getVideoTracks());
    return v.play().then(function () {
      return new Promise(function (r) { setTimeout(r, 300); });
    }).then(function () {
      var c = document.createElement('canvas');
      c.width = v.videoWidth; c.height = v.videoHeight;
      c.getContext('2d').drawImage(v, 0, 0);
      v.srcObject = null;
      return { ok: true, w: c.width, h: c.height, url: c.toDataURL('image/jpeg', 0.8) };
    }, function (e) { return { ok: false, error: String(e) }; });
  }

  // Yakalanan kare boyu değişirse (pencere boyu, tam ekran) bölge yeniden çevrilir
  setInterval(function () {
    if (!cur || !cur.stream) return;
    var fsz = frameSize();
    if (fsz && fsz.w + 'x' + fsz.h !== cur.appliedFor) applyRegion();
  }, 1500);

  C.runtime.onMessage.addListener(function (msg, sender, reply) {
    if (!msg || msg.to !== 'engine') return false;
    if (!sender || sender.id !== C.runtime.id) return false;
    if (msg.cmd === 'start') {
      start(msg).then(reply);
      return true;
    }
    if (cur && msg.sid !== cur.sid) { reply({ ok: false, stale: true }); return false; }
    if (msg.cmd === 'stop') { stop(); reply({ ok: true }); }
    else if (msg.cmd === 'region') {
      if (cur) { cur.region = msg.region || cur.region; cur.viewport = msg.viewport || cur.viewport; applyRegion(); }
      reply({ ok: true });
    } else if (msg.cmd === 'settings') { applySettings(msg.settings); reply({ ok: true }); }
    else if (msg.cmd === 'ping') {
      reply({ ok: true, sid: cur && cur.sid, region: AS.settings.get('ocrRegion'), frame: frameSize(), viewport: cur && cur.viewport,
        stats: AS.modes.live.stats ? AS.modes.live.stats() : null });
    } else if (msg.cmd === 'snap') { snap().then(reply); return true; }
    else reply({ ok: false });
    return false;
  });

  if (stopBtn) stopBtn.addEventListener('click', function () {
    try { C.runtime.sendMessage({ to: 'bg', cmd: 'stop' }); } catch (e) { /* yok */ }
    stop();
  });
  window.addEventListener('pagehide', function () { stop(); });

  // Açılınca bekleyen başlat komutunu iste
  try {
    var hp = C.runtime.sendMessage({ from: 'engine', type: 'hello', kind: KIND });
    if (hp && typeof hp.then === 'function') {
      hp.then(function (cmd) { if (cmd && cmd.cmd === 'start') start(cmd); }, function () { /* yok */ });
    }
  } catch (e) { /* yok */ }

  // Testler için (yalnızca bu sayfanın kendi bağlamında görünür)
  window.__asEngine = { start: start, stop: stop, frameRegion: frameRegion, kind: KIND, cur: function () { return cur; } };
})();
