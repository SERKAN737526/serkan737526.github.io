#!/bin/bash
# Altyazı Şefi: Safari eklentisini KALICI kurar (Mac). Xcode gerekir (App Store'da ücretsiz).
#
# Ne yapar:
#   1. Bu klasördeki eklenti/ klasörünü Apple'ın aracıyla (safari-web-extension-packager) bir Mac uygulamasına çevirir.
#   2. İlk seferde Xcode'u açar: orada bir kez Apple kimliğini ("Team") seçersin, Xcode'u kapatıp bu dosyayı yeniden açarsın.
#   3. Uygulamayı senin Apple kimliğinle imzalayıp derler, ~/Applications (Uygulamalar) içine koyar ve açar.
#   Sonra Safari > Ayarlar > Uzantılar'da Altyazı Şefi'yi işaretlersin. Eklenti Safari kapanınca silinmez.
# Güncellemede: yeni sürümün bu dosyasına çift tıkla; Team hatırlanır, yalnızca yeniden derlenir.
# İnternete yalnızca Xcode (Apple) imza için bağlanır; bu betik başka hiçbir yere bir şey göndermez.

APP_NAME="Altyazi Sefi"
BUNDLE_ID="com.serkan737526.altyazisefi"
HERE="$(cd "$(dirname "$0")" && pwd)"
EXT="$HERE/eklenti"
BASE="$HOME/Documents/AltyaziSefi-Safari"   # Belgeler/AltyaziSefi-Safari
PROJ="$BASE/proje"
TEAM_FILE="$BASE/takim.txt"
LOG="$BASE/derleme.log"

say() { printf '\n%s\n' "$*"; }
finish() { printf '\n'; read -r -p "Pencereyi kapatmak için Enter'a bas. " _; exit "${1:-0}"; }
dialog() { /usr/bin/osascript -e "display dialog \"$1\" buttons {\"Tamam\"} default button 1 with title \"Altyazı Şefi\"" >/dev/null 2>&1; }

say "Altyazı Şefi: Safari eklentisi kurulumu"

if [ ! -f "$EXT/manifest.json" ]; then
  say "HATA: eklenti klasörü bulunamadı ($EXT). Zip'in içindeki klasörün tamamını açıp bu dosyayı oradan çalıştır."
  finish 1
fi

# Xcode: Komut satırı araçları seçili olsa bile tam Xcode'u kullan
if [ -d "/Applications/Xcode.app" ]; then
  export DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer"
fi
if ! xcrun --find xcodebuild >/dev/null 2>&1 || [ ! -d "/Applications/Xcode.app" ]; then
  say "Xcode kurulu değil. App Store'da Xcode sayfası açılıyor: 'Al' / 'Yükle' de (ücretsiz, büyük bir indirme)."
  say "Kurulunca Xcode'u bir kez aç, lisansı kabul et, sonra bu dosyaya yeniden çift tıkla."
  open "macappstore://apps.apple.com/app/id497799835" 2>/dev/null
  finish 1
fi
if ! xcodebuild -checkFirstLaunchStatus >/dev/null 2>&1; then
  say "Xcode'un ilk açılışı tamamlanmamış. Xcode açılıyor: lisansı kabul et ve bileşenleri kur, sonra Xcode'u kapatıp bu dosyaya yeniden çift tıkla."
  open -a Xcode
  finish 1
fi
PACKAGER="$(xcrun --find safari-web-extension-packager 2>/dev/null || xcrun --find safari-web-extension-converter 2>/dev/null)"
if [ -z "$PACKAGER" ]; then
  say "HATA: Xcode'da Safari eklenti aracı bulunamadı. Xcode'u App Store'dan güncelleyip yeniden dene."
  finish 1
fi

mkdir -p "$BASE"
XP="$(find "$PROJ" -maxdepth 3 -name '*.xcodeproj' 2>/dev/null | head -n 1)"

# Daha önce seçilen Team (Apple kimliği): kayıttan ya da Xcode'da seçilmişse projeden
TEAM=""
[ -f "$TEAM_FILE" ] && TEAM="$(tr -cd 'A-Z0-9' < "$TEAM_FILE")"
if [ -z "$TEAM" ] && [ -n "$XP" ]; then
  TEAM="$(grep -o 'DEVELOPMENT_TEAM = [A-Z0-9]\{10\};' "$XP/project.pbxproj" 2>/dev/null | head -n 1 | sed 's/.*= \([A-Z0-9]*\);/\1/')"
fi

if [ -z "$TEAM" ]; then
  # İLK SEFER: projeyi hazırla, Xcode'da Team seçtir
  say "Uygulama projesi hazırlanıyor…"
  if ! "$PACKAGER" "$EXT" --project-location "$PROJ" --app-name "$APP_NAME" --bundle-identifier "$BUNDLE_ID" \
       --swift --macos-only --copy-resources --no-open --no-prompt --force > "$LOG" 2>&1; then
    cat "$LOG"; say "HATA: proje hazırlanamadı. Bu pencerenin ekran görüntüsünü gönder."; finish 1
  fi
  XP="$(find "$PROJ" -maxdepth 3 -name '*.xcodeproj' | head -n 1)"
  open "$XP"
  say "Xcode açıldı. Şimdi bir kez şunları yap:"
  say "  1. Soldaki listenin en üstündeki '$APP_NAME' (mavi simge) satırına tıkla."
  say "  2. Ortada 'Signing & Capabilities' sekmesine geç."
  say "  3. TARGETS listesinde önce '$APP_NAME' seç: 'Team' kutusundan 'Add an Account…' ile Apple kimliğinle giriş yap,"
  say "     sonra 'Ad Soyad (Personal Team)' seç."
  say "  4. TARGETS listesinde '$APP_NAME Extension' seç ve 'Team' kutusunda aynı 'Personal Team'i seç."
  say "  5. Cmd+S ile kaydet, Xcode'u kapat (Cmd+Q) ve bu dosyaya yeniden çift tıkla."
  dialog "Xcode'da Signing & Capabilities sekmesinde iki hedef için de Apple kimliğini (Personal Team) seç, Xcode'u kapat ve kurulum dosyasına yeniden çift tıkla. Adımlar Terminal penceresinde yazıyor."
  finish 0
fi

# İKİNCİ SEFER ve GÜNCELLEMELER: (yeniden) paketle, imzala, derle, kur
say "Apple kimliği (Team) bulundu: $TEAM"
say "Eklenti paketleniyor…"
if ! "$PACKAGER" "$EXT" --project-location "$PROJ" --app-name "$APP_NAME" --bundle-identifier "$BUNDLE_ID" \
     --swift --macos-only --copy-resources --no-open --no-prompt --force > "$LOG" 2>&1; then
  cat "$LOG"; say "HATA: proje hazırlanamadı. Bu pencerenin ekran görüntüsünü gönder."; finish 1
fi
printf '%s' "$TEAM" > "$TEAM_FILE"
XP="$(find "$PROJ" -maxdepth 3 -name '*.xcodeproj' | head -n 1)"
SCHEME="$(xcodebuild -list -project "$XP" 2>/dev/null | awk '/Schemes:/{f=1;next} f&&NF{gsub(/^[ \t]+/,"");print}' | grep -v -i 'extension' | head -n 1)"
[ -z "$SCHEME" ] && SCHEME="$APP_NAME"
say "Derleniyor ve imzalanıyor (biraz sürebilir)…"
if ! xcodebuild -project "$XP" -scheme "$SCHEME" -configuration Release -derivedDataPath "$BASE/derleme" \
     -allowProvisioningUpdates DEVELOPMENT_TEAM="$TEAM" CODE_SIGN_STYLE=Automatic build >> "$LOG" 2>&1; then
  grep -E 'error:|No Account|No signing|requires a development team' "$LOG" | tail -n 8
  say "HATA: derlenemedi. Xcode > Settings > Accounts'ta Apple kimliğin ekli mi bak, sonra yeniden dene."
  say "Olmazsa bu pencerenin ekran görüntüsünü gönder. Ayrıntı: $LOG"
  rm -f "$TEAM_FILE"
  finish 1
fi
BUILT="$(find "$BASE/derleme/Build/Products/Release" -maxdepth 1 -name '*.app' | head -n 1)"
if [ -z "$BUILT" ]; then say "HATA: derlenen uygulama bulunamadı. Ayrıntı: $LOG"; finish 1; fi
mkdir -p "$HOME/Applications"
DEST="$HOME/Applications/$(basename "$BUILT")"
osascript -e "tell application \"$(basename "$BUILT" .app)\" to quit" >/dev/null 2>&1
rm -rf "$DEST"
cp -R "$BUILT" "$DEST"
open "$DEST"
say "Kuruldu: $DEST"
say "Şimdi Safari'de: Safari > Ayarlar > Uzantılar > 'Altyazı Şefi' kutusunu işaretle."
say "Safari izin sorarsa 'Her web sitesinde izin ver' de. Simge adres çubuğunun yanında çıkar."
dialog "Kurulum bitti. Safari > Ayarlar > Uzantılar'da Altyazı Şefi'yi işaretle ve web sitelerine izin ver."
finish 0
